module Main(main) where
import Graphics.Gloss
import Codec.Picture
import Graphics.Gloss.Data.Bitmap 
import Codec.Picture.Types
import Graphics.Gloss.Data.ViewPort
import Graphics.Gloss.Interface.Pure.Game


import Codec.Picture
import Graphics.Gloss

import Codec.Picture
import Codec.Picture.Types
import Graphics.Gloss
import Graphics.Gloss.Data.Bitmap

-- | Load a PNG file and convert it to a 'Picture' object.
loadPicture :: FilePath -> IO (Either String Picture)
loadPicture path = do
  result <- decodeImage <$> readFile path
  case result of
    Left err -> pure $ Left err
    Right dynamicImage -> pure $ Right $ bitmapOfDynamicImage dynamicImage False

-- | Display a 'Picture' in a window.
displayPicture :: Picture -> IO ()
displayPicture picture =
  display
    (InWindow "Image" (800, 600) (10, 10))
    white
    picture

main :: IO ()
main = do
  -- Load the PNG file.
  result <- loadPicture "/Users/mariabonde/inf221/bouncingdvd/app/DVD_logo.svg.png"
  case result of
    Left err -> putStrLn $ "Failed to load image: " ++ err
    Right picture -> do
      -- Display the picture in a window.
      displayPicture picture


{-
import Codec.Picture.Repa (readImageRGBA, toByteString, reverseColorChannel)
import Graphics.Gloss

readPng :: FilePath -> Int -> Int -> IO Picture
readPng path w h = do
  (Right img) <- readImageRGBA path
  let bs = toByteString $ reverseColorChannel img
  return $ bitmapOfByteString w h (BitmapFormat TopToBottom PxRGBA) bs True

width, height, offset :: Int
width = 300
height = 300
offset = 100
window :: Display
window = InWindow "bouncingDVD" (width, height) (offset, offset)

background :: Color
background = black

drawing :: Picture
drawing = pictures
  [ translate (-20) (-100) $ color ballColor $ circleSolid 30 
  , translate 30 50 $ color paddleColor $ rectangleSolid 10 50
  ]
  where
    ballColor = dark red
    paddleColor = light (light blue)

data LogoState = Logo {
  logoLoc :: (Float, Float), 
  logoVel :: (Float, Float)} 
fps :: Int
fps = 600
type Radius = Float 
type Position = (Float, Float)
--detect collision with a wall and change direction upon the collision
wallBounce :: LogoState -> LogoState
wallBounce game = game {logoVel = (vx, vy') } 
  where 
    -- Radius. Use the same thing as in `render``
    radius = 10
    (vx, vy) = logoVel game 

    vy' = if wallCollision (logoLoc game) radius 
      then 
        --update the velocity
        -vy
        else 
          vy
        
wallCollision :: Position -> Radius -> Bool 
wallCollision (_,y) radius = topCollision || bottomCollision 
  where 
    topCollision = y - radius <= -fromIntegral width / 2 
    bottomCollision = y + radius <= fromIntegral width / 2

update :: ViewPort -> Float -> LogoState -> LogoState
update _ seconds = wallBounce . moveLogo seconds 


initialState = Logo {logoLoc = (-40,30), logoVel = (100,-300)}
moveLogo :: Float -> LogoState -> LogoState
moveLogo seconds state = state { logoLoc = (x', y')}
  where 
    (x,y) = logoLoc state
    (vx,vy) = logoVel state

    x' = x + vx * seconds
    y' = y + vy * seconds

render :: LogoState -> Picture
render state = 
  pictures [logo, walls] 
  where 
    logo = uncurry translate (logoLoc state) $ color ballColor $ circleSolid 10
    ballColor = dark red

    wall :: Float -> Picture 
    wall offset = 
      translate 0 offset $ 
        color wallColor $ 
          rectangleSolid 270 10
    wallColor = greyN 0.5
    walls = pictures [wall 150, wall(-150)]


main :: IO ()
main = simulate window background fps initialState render update

-}

